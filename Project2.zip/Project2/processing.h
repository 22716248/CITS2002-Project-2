#ifndef PROCESSING_H_   /* Include guard */
#define PROCESSING_H_

extern void processFiles(char *basedir, char *finalpath);


#endif